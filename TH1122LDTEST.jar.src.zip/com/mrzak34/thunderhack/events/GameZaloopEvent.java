package com.mrzak34.thunderhack.events;

import net.minecraftforge.fml.common.eventhandler.Event;

public class GameZaloopEvent extends Event {}


/* Location:              C:\Users\vchteam\Desktop\testpasrt\TH1122LDTEST.jar!\com\mrzak34\thunderhack\events\GameZaloopEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */