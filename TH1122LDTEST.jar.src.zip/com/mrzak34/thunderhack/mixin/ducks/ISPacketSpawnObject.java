package com.mrzak34.thunderhack.mixin.ducks;

public interface ISPacketSpawnObject {
  boolean isAttacked();
  
  void setAttacked(boolean paramBoolean);
}


/* Location:              C:\Users\vchteam\Desktop\testpasrt\TH1122LDTEST.jar!\com\mrzak34\thunderhack\mixin\ducks\ISPacketSpawnObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */