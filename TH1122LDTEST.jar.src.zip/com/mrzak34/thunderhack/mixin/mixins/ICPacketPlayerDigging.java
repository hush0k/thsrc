package com.mrzak34.thunderhack.mixin.mixins;

public interface ICPacketPlayerDigging {
  boolean isClientSideBreaking();
  
  void setClientSideBreaking(boolean paramBoolean);
}


/* Location:              C:\Users\vchteam\Desktop\testpasrt\TH1122LDTEST.jar!\com\mrzak34\thunderhack\mixin\mixins\ICPacketPlayerDigging.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */