/*    */ package com.mrzak34.thunderhack.gui.clickui;
/*    */ 
/*    */ import java.awt.Color;
/*    */ 
/*    */ public class Colors
/*    */ {
/*  7 */   public static Color CLIENT_COLOR = new Color(64, 169, 248);
/*  8 */   public static Color ALTERNATE_COLOR = new Color(-1);
/*  9 */   public static Color COLOR = new Color(-15709185);
/* 10 */   public static Color RIPPLE_COLOR = new Color(12, 12, 12, 80);
/* 11 */   public static Color DIVIDER_COLOR = new Color(-7697782);
/*    */ }


/* Location:              C:\Users\vchteam\Desktop\testpasrt\TH1122LDTEST.jar!\com\mrzak34\thunderhack\gui\clickui\Colors.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */