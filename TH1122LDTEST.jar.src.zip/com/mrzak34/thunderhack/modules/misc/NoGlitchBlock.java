/*   */ package com.mrzak34.thunderhack.modules.misc;
/*   */ 
/*   */ import com.mrzak34.thunderhack.modules.Module;
/*   */ 
/*   */ public class NoGlitchBlock extends Module {
/*   */   public NoGlitchBlock() {
/* 7 */     super("NoGlitchBlock", "убирает залаг ломания-блока", "NoGlitchBlock", Module.Category.MISC);
/*   */   }
/*   */ }


/* Location:              C:\Users\vchteam\Desktop\testpasrt\TH1122LDTEST.jar!\com\mrzak34\thunderhack\modules\misc\NoGlitchBlock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */