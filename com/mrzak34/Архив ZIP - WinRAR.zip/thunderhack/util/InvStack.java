/*    */ package com.mrzak34.thunderhack.util;
/*    */ 
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class InvStack
/*    */ {
/*    */   public final int slot;
/*    */   public final ItemStack stack;
/*    */   
/*    */   public InvStack(int slot, ItemStack stack) {
/* 11 */     this.slot = slot;
/* 12 */     this.stack = stack;
/*    */   }
/*    */ }


/* Location:              C:\Users\vchteam\Desktop\testpasrt\TH1122LDTEST.jar!\com\mrzak34\thunderhac\\util\InvStack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */