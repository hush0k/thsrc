/*   */ package com.mrzak34.thunderhack.util.math;
/*   */ 
/*   */ public enum AnimationMode {
/* 4 */   LINEAR,
/* 5 */   EXPONENTIAL;
/*   */ }


/* Location:              C:\Users\vchteam\Desktop\testpasrt\TH1122LDTEST.jar!\com\mrzak34\thunderhac\\util\math\AnimationMode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */