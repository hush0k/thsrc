/*   */ package com.mrzak34.thunderhack.notification;
/*   */ 
/*   */ public enum Direction {
/* 4 */   FORWARDS,
/* 5 */   BACKWARDS;
/*   */ }


/* Location:              C:\Users\vchteam\Desktop\testpasrt\TH1122LDTEST.jar!\com\mrzak34\thunderhack\notification\Direction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */