/*    */ package com.mrzak34.thunderhack.modules.render;
/*    */ 
/*    */ import com.mrzak34.thunderhack.modules.Module;
/*    */ 
/*    */ public class EzingKids extends Module {
/*    */   public static EzingKids INSTANCE;
/*    */   
/*    */   public EzingKids() {
/*  9 */     super("AkrienUser", "делает тебя мелким", Module.Category.RENDER);
/* 10 */     INSTANCE = this;
/*    */   }
/*    */ }


/* Location:              C:\Users\vchteam\Desktop\testpasrt\TH1122LDTEST.jar!\com\mrzak34\thunderhack\modules\render\EzingKids.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */