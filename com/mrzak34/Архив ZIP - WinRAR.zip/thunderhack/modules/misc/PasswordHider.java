/*   */ package com.mrzak34.thunderhack.modules.misc;
/*   */ 
/*   */ import com.mrzak34.thunderhack.modules.Module;
/*   */ 
/*   */ public class PasswordHider extends Module {
/*   */   public PasswordHider() {
/* 7 */     super("PasswordHider", "Прячет пароль если-введено /l или /reg", Module.Category.MISC);
/*   */   }
/*   */ }


/* Location:              C:\Users\vchteam\Desktop\testpasrt\TH1122LDTEST.jar!\com\mrzak34\thunderhack\modules\misc\PasswordHider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */