/*   */ package com.mrzak34.thunderhack.modules.misc;
/*   */ 
/*   */ import com.mrzak34.thunderhack.modules.Module;
/*   */ 
/*   */ public class Shulkerception extends Module {
/*   */   public Shulkerception() {
/* 7 */     super("Shulkerception", "класть шалкера в шалкера-(одиночка)", Module.Category.MISC);
/*   */   }
/*   */ }


/* Location:              C:\Users\vchteam\Desktop\testpasrt\TH1122LDTEST.jar!\com\mrzak34\thunderhack\modules\misc\Shulkerception.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */