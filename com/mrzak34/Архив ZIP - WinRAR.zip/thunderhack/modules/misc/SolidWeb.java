/*   */ package com.mrzak34.thunderhack.modules.misc;
/*   */ 
/*   */ import com.mrzak34.thunderhack.modules.Module;
/*   */ 
/*   */ public class SolidWeb
/*   */   extends Module {
/*   */   public SolidWeb() {
/* 8 */     super("SolidWeb", "SolidWeb", Module.Category.MISC);
/*   */   }
/*   */ }


/* Location:              C:\Users\vchteam\Desktop\testpasrt\TH1122LDTEST.jar!\com\mrzak34\thunderhack\modules\misc\SolidWeb.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */