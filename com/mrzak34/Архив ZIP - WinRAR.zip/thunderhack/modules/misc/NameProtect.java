/*   */ package com.mrzak34.thunderhack.modules.misc;
/*   */ 
/*   */ import com.mrzak34.thunderhack.modules.Module;
/*   */ 
/*   */ public class NameProtect extends Module {
/*   */   public NameProtect() {
/* 7 */     super("NameProtect", "прячет твой ник", Module.Category.MISC);
/*   */   }
/*   */ }


/* Location:              C:\Users\vchteam\Desktop\testpasrt\TH1122LDTEST.jar!\com\mrzak34\thunderhack\modules\misc\NameProtect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */