/*   */ package com.mrzak34.thunderhack.modules.movement;
/*   */ 
/*   */ import com.mrzak34.thunderhack.modules.Module;
/*   */ 
/*   */ public class NoJumpDelay extends Module {
/*   */   public NoJumpDelay() {
/* 7 */     super("NoJumpDelay", "NoJumpDelay", Module.Category.PLAYER);
/*   */   }
/*   */ }


/* Location:              C:\Users\vchteam\Desktop\testpasrt\TH1122LDTEST.jar!\com\mrzak34\thunderhack\modules\movement\NoJumpDelay.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */