/*   */ package com.mrzak34.thunderhack.modules.player;
/*   */ 
/*   */ import com.mrzak34.thunderhack.modules.Module;
/*   */ 
/*   */ public class NoCameraClip extends Module {
/*   */   public NoCameraClip() {
/* 7 */     super("NoCameraClip", "камера не будет-приближаться", "removes camera collision", Module.Category.PLAYER);
/*   */   }
/*   */ }


/* Location:              C:\Users\vchteam\Desktop\testpasrt\TH1122LDTEST.jar!\com\mrzak34\thunderhack\modules\player\NoCameraClip.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */