package com.mrzak34.thunderhack.mixin.ducks;

public interface IEntityPlayerSP {
  void setAuraCallback(Runnable paramRunnable);
  
  void addAuraCallback(Runnable paramRunnable);
}


/* Location:              C:\Users\vchteam\Desktop\testpasrt\TH1122LDTEST.jar!\com\mrzak34\thunderhack\mixin\ducks\IEntityPlayerSP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */