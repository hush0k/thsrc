/*    */ package com.mrzak34.thunderhack.setting;
/*    */ 
/*    */ public class PositionSetting
/*    */ {
/*    */   public float x;
/*    */   public float y;
/*    */   
/*    */   public PositionSetting(float x, float y) {
/*  9 */     this.x = x;
/* 10 */     this.y = y;
/*    */   }
/*    */   
/*    */   public void setX(float posx) {
/* 14 */     this.x = posx;
/*    */   }
/*    */   
/*    */   public float getX() {
/* 18 */     return this.x;
/*    */   }
/*    */   public void setY(float posy) {
/* 21 */     this.y = posy;
/*    */   }
/*    */   
/*    */   public float getY() {
/* 25 */     return this.y;
/*    */   }
/*    */ }


/* Location:              C:\Users\vchteam\Desktop\testpasrt\TH1122LDTEST.jar!\com\mrzak34\thunderhack\setting\PositionSetting.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */