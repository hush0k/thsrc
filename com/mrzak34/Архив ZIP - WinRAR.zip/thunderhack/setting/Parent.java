/*    */ package com.mrzak34.thunderhack.setting;
/*    */ 
/*    */ public class Parent {
/*    */   private boolean extended;
/*    */   
/*    */   public Parent(boolean extended) {
/*  7 */     this.extended = extended;
/*    */   }
/*    */   
/*    */   public boolean isExtended() {
/* 11 */     return this.extended;
/*    */   }
/*    */   
/*    */   public void setExtended(boolean extended) {
/* 15 */     this.extended = extended;
/*    */   }
/*    */ }


/* Location:              C:\Users\vchteam\Desktop\testpasrt\TH1122LDTEST.jar!\com\mrzak34\thunderhack\setting\Parent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */